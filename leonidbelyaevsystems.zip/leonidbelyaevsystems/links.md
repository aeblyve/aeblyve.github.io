---
build_date: 2024-05-19 20:35:05+00:00
title: Links
link: https://leonid.belyaev.systems/links.html
---


* [Ray Peat](https://raypeat.com/)
* [0x0.st](https://0x0.st/)
* [BEHEMOTH](https://microship.com/behemoth/)
* [Amish Hackers](https://kk.org/thetechnium/amish-hackers-a/)
* [Bits about Money](https://www.bitsaboutmoney.com/)
* [NASA ANTHROPOMETRY](https://msis.jsc.nasa.gov/sections/section03.htm)
* [Gridfinity](https://gridfinity.xyz/)
* [Low Tech Magazine](https://solar.lowtechmagazine.com/)
* [Blake Archive](https://blakearchive.org/)
* [USB Differential Pair Routing](https://www.masterzen.fr/2020/10/20/designing-a-keyboard-part3/#usb-differential-pair)